var fs = require("fs");
var filtereDataEmployess = require("./input1.json");
// console.log("this is filteredDataEmployes", filtereDataEmployess);
var filtereDataIndians = require("./input3.json");
// console.log("this is filteredDataEmployes", filtereDataIndians);

const compareNames = (filtereDataEmployess, filtereDataIndians) => {
  for (i = 0; i < filtereDataEmployess.length; i++) {
    return filtereDataEmployess[i].name === filtereDataIndians[i].name;
  }
};
// compareNames();
console.log("this is names", filtereDataEmployess[9].name);

// const data = require("./employees.json");
// const newData = require("./indianNames.json");

// var jsonObject = newData.map(JSON.stringify);

// var uniqueSet = new Set(jsonObject);
// var uniqueArray = Array.from(uniqueSet);

// fs.writeFile("input3.json", uniqueArray, function (error) {
//   if (error) {
//     console.error("write error:  " + error.message);
//   } else {
//     console.log("Successful Write to ");
//   }
// });
