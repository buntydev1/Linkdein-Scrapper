const { startBrowser } = require("./browser");

startBrowser();
